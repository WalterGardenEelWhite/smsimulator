#ifndef TDALISIMDATA_HH
#define TDALISIMDATA_HH

#include <vector>
#include "TSimData.hh"

typedef std::vector<TSimData> TDALISimDataArray;
extern TDALISimDataArray* gDALISimDataArray;

#endif

