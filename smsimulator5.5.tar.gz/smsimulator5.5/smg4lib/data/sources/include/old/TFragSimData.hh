#ifndef TFRAGSIMDATA_HH
#define TFRAGSIMDATA_HH

#include <vector>
#include "TSimData.hh"

typedef std::vector<TSimData> TFragSimDataArray;
extern TFragSimDataArray* gFragSimDataArray;

#endif

