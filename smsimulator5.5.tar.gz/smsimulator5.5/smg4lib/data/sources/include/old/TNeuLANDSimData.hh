#ifndef TNeuLANDSIMDATA_HH
#define TNeuLANDSIMDATA_HH

#include <vector>
#include "TSimData.hh"

typedef std::vector<TSimData> TNeuLANDSimDataArray;
extern TNeuLANDSimDataArray* gNeuLANDSimDataArray;

#endif

