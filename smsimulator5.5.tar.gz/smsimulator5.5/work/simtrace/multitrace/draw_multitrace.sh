#!/bin/bash
root -l -q multitrace/run_generator.cc
simtrace multitrace/multitrace.mac
