
#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class TArtCrosstalkAnalysis+;
#pragma link C++ class TArtCrosstalkAnalysis_DoNothing+;
#pragma link C++ class TArtCrosstalkAnalysis_NEBULANeuLAND_Example+;
#pragma link C++ class TArtCrosstalkAnalysis_NEBULANeuLAND_samurai21_7+;
#pragma link C++ class TArtCrosstalkAnalysis_NEBULANeuLAND_samurai21_8+;

#endif
